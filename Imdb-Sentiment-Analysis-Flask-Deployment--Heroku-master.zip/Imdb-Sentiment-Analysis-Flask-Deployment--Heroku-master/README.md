# Imdb-Sentiment-Analysis-Flask-Deployment
Heroku App Link - http://imdbsentimentanalysis.herokuapp.com/
